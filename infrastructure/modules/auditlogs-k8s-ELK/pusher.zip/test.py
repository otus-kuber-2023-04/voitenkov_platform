def test(a):
    pass
